import * as fs from "node:fs";
import * as path from "node:path";
import { expect, test } from "@playwright/test";
import * as ts from "typescript";

// Real-browser regression test for artifacts/novamail-web/src/lib/editor-html.ts.
// The compose editor assigns asEditorHtml(...) to innerHTML for replies/forwards, AI suggestions, templates and
// drafts, and stripHtml(...) parses the same content. Reply/forward text comes from the received message
// (sender-controlled), so none of these helpers may let markup execute script. No backend/auth is needed here.
const sourcePath = path.resolve(process.cwd(), process.env.EDITOR_HTML_SOURCE ?? "artifacts/novamail-web/src/lib/editor-html.ts");
const transpiled = ts.transpileModule(fs.readFileSync(sourcePath, "utf8"), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText;
const bundle = `(function(){var exports={};${transpiled}\nwindow.EditorHtml=exports;})();`;

const mark = (tag: string) => `window.__xss.push('${tag}')`;
const payloads: Record<string, string> = {
  "img onerror": `<img src=x onerror="${mark("img")}">`,
  "details ontoggle": `<details open ontoggle="${mark("details")}">x</details>`,
  "iframe srcdoc": `<iframe srcdoc="<script>parent.${mark("iframe")}</script>"></iframe>`,
  "input autofocus": `<input autofocus onfocus="${mark("input")}">`,
  "quoted reply (subject and body)": `---------- Original message ----------\nFrom: x <a@b.c>\nSubject: <img src=x onerror="${mark("reply")}">\nTo: me\n\nhello`,
};

test.describe("compose editor HTML helpers (real browser)", () => {
  test.beforeEach(async ({ page }) => {
    await page.setContent('<div id="editor" contenteditable="true"></div>');
    await page.evaluate(() => {
      (window as unknown as { __xss: string[] }).__xss = [];
    });
    await page.addScriptTag({ content: bundle });
  });

  for (const [name, payload] of Object.entries(payloads)) {
    test(`does not execute script: ${name}`, async ({ page }) => {
      await page.evaluate((value) => {
        const helpers = (window as unknown as { EditorHtml: { asEditorHtml(v: string): string; stripHtml(v: string): string } }).EditorHtml;
        document.getElementById("editor")!.innerHTML = helpers.asEditorHtml(value);
        helpers.stripHtml(value);
      }, payload);
      await page.waitForTimeout(250);
      expect(await page.evaluate(() => (window as unknown as { __xss: string[] }).__xss)).toEqual([]);
    });
  }

  test("keeps editor formatting, Arabic/RTL text and safe links; drops unsafe ones", async ({ page }) => {
    const result = await page.evaluate(() => {
      const helpers = (window as unknown as { EditorHtml: { asEditorHtml(v: string): string; stripHtml(v: string): string } }).EditorHtml;
      return {
        rich: helpers.asEditorHtml('<p>Hello <b>bold</b> <i>it</i> <u>u</u></p><ul><li>one</li></ul><a href="https://example.com/x?a=1">l</a>'),
        rtl: helpers.asEditorHtml('<div dir="rtl">مرحبا <b>بالعالم</b></div>'),
        plain: helpers.asEditorHtml('line1\nline2 & <3'),
        links: helpers.asEditorHtml('<a href="javascript:alert(1)">bad</a><a href="mailto:a@b.c">ok</a>'),
        stripped: helpers.stripHtml("<p>a&nbsp;b <b>c</b></p>"),
      };
    });
    expect(result.rich).toContain("<b>bold</b>");
    expect(result.rich).toContain("<ul><li>one</li></ul>");
    expect(result.rich).toContain('href="https://example.com/x?a=1"');
    expect(result.rtl).toBe('<div dir="rtl">مرحبا <b>بالعالم</b></div>');
    expect(result.plain).toBe("<p>line1<br />line2 &amp; &lt;3</p>");
    expect(result.links).not.toMatch(/javascript/i);
    expect(result.links).toContain('href="mailto:a@b.c"');
    expect(result.stripped).toBe("a b c");
  });
});
