# Zephyx Mail Flutter

Mobile client for Zephyx Mail — built with Flutter for Android, iOS, and Web.

## Setup

### Prerequisites
- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android Studio / Xcode for device builds

### Installation

```bash
cd mobile/novamail-flutter
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
```

### Running

`API_BASE_URL` must be an absolute URL that **includes the `/api` prefix**. `validateApiBaseUrl()` (see
`lib/core/network/api_client.dart`, enforced by `test/api_client_config_test.dart`) rejects `localhost`,
`127.0.0.1`, `::1` and `10.0.2.2` in every build mode, and release builds additionally require HTTPS.
Point debug builds at a reachable host instead, e.g. your machine's LAN IP or a staging/tunnel URL:

```bash
# Android / iOS / Web (replace the host with a reachable, non-loopback address)
flutter run -d android --dart-define=API_BASE_URL=http://<your-lan-ip>:5000/api
flutter run -d ios     --dart-define=API_BASE_URL=http://<your-lan-ip>:5000/api
flutter run -d chrome  --dart-define=API_BASE_URL=https://<staging-host>/api
```

### Building for production

```bash
# Android APK
flutter build apk --release --dart-define=API_BASE_URL=https://your-api.com/api

# iOS
flutter build ios --release --dart-define=API_BASE_URL=https://your-api.com/api

# Web
flutter build web --dart-define=API_BASE_URL=https://your-api.com/api
```

## Project Structure

```
lib/
├── main.dart
├── core/
│   ├── network/     — Dio HTTP client with JWT auth + refresh
│   ├── router/      — GoRouter navigation
│   └── theme/       — App theme (light/dark, RTL support)
├── features/
│   ├── auth/        — Login, register, auth state
│   ├── inbox/       — Email list
│   ├── email_detail/ — Email reading
│   ├── compose/     — Compose new emails
│   └── settings/    — Theme, language, profile
├── shared/
│   └── screens/     — Splash, error screens
└── l10n/            — English + Arabic localizations
```

## Localisation (i18n)

Supports English and Arabic (RTL). Extend `lib/l10n/app_localizations.dart`
with ARB files to add more strings.
