# جاهزية النشر — Zephyx Mail

تاريخ التقييم: 2026-10-15

## 1. الحكم

**غير مُثبَت كجاهز للإنتاج.** تعديل الملفات لا يكفي: لم تُنفَّذ في بيئة التدقيق (بلا شبكة) خطوات التثبيت و`tsc` الكامل واختبارات vitest/jest والبناء الكامل وPrisma وClamAV الحقيقي وFlutter وGmail OAuth.
البنية العامة سليمة بحسب ما أمكن فحصه (انظر `docs/TEST_RESULTS.md`)، لكن القرار يجب أن يستند إلى تشغيل الخطوات في القسم 5 عندك.

### ما يمنع اعتباره جاهزًا الآن

| # | العائق | ما يلزم |
|---|--------|---------|
| 1 | لم يُشغَّل `pnpm run verify` ولا اختبارات التكامل ولا بناء الإنتاج | تشغيلها بالشبكة (القسم 5) |
| 2 | تصدير تقرير الأمان PDF يحتاج حزم fontkit غير المعلنة (حاليًا يُرجع 503) | شغّل `./scripts/add-pdf-font-dependencies.sh` (يحتاج شبكة وpnpm وnpm؛ يكتشف إصدار fontkit بمطابقة بصمة الملف المضمَّن `1cac5f3c…` مع `dist/main.cjs` لكل إصدار 2.x، ثم يحدّث `pnpm-lock.yaml` بـ`pnpm add` ويتحقق بـ`check-undeclared-imports.mjs`؛ يقبل `FONTKIT_VERSION=` لتسمية الإصدار) وثبّت التغييرين. اختياري إن لم تحتج هذه الميزة. لم يُشغَّل هنا |
| 3 | لم يُتحقق من Google Cloud ولا Replit Secrets ولا من العنوان الحي | القسم 2 و3 و6 |
| 4 | ClamAV لم يُختبر بمحرك حقيقي | القسم 7 |
| 5 | تغيير سلوك: السكربت يفرض الآن `NODE_ENV=production` افتراضيًا (FIX-05) | تأكّد أن كل المتغيرات في القسم 3 مضبوطة قبل النشر |
| 6 | تطبيق Flutter لم يُبنَ ولم تُشغَّل اختباراته (بما فيها التعديلان الجديدان) | القسم 8 |
| 7 | تعديلات الجزء الرابع على `enterprise.service.ts` (عضوية، حوادث، معاملة) لم تُنفَّذ على قاعدة بيانات؛ وحظر الصور في `EmailDetail` لم يُجرَّب في متصفح | اختبارات التكامل على قاعدة تجريبية + فحص يدوي (القسم 9) |
| 8 | تعديلات الجزء الخامس (الإشعارات، الملاحظات، الإنتاجية) التي تمر عبر قاعدة البيانات، وFCM وGemini الحقيقيان، لم تُنفَّذ؛ واختبارات هذه الوحدات كُتبت بصيغة vitest ولم تُشغَّل بـvitest الحقيقي | تشغيل `pnpm run test:unit && pnpm run test:integration` ثم الفحوص اليدوية 15–21 |

## 2. أي عنوان نشر تستخدمه النسخة الحالية؟

الأدلة داخل المشروع:

- **لا يظهر أي من العنوانين اللذين ذكرتهما في أي ملف** (`zephyx-mail-2--shehabalhusaami.replit.app` و`zephyx-mail-complete-current-backu-pzip--shhabalhsamy81.replit.app`): 0 تطابق.
- العنوان الوحيد من نوع Replit في الملفات هو `https://nova-mail-account-3--shehabalhsamy05.replit.app/` وهو **عنوان ثالث** قديم داخل `artifacts/novamail-web/index.html` (canonical وOpen Graph فقط). لم أغيّره لأنني لا أعرف العنوان الصحيح.
- كل ما يخص OAuth والـCORS مبني على متغيرات بيئة (`GOOGLE_REDIRECT_URI`, `APP_BASE_URL`, `NOVAMAIL_WEB_URL`, `ALLOWED_ORIGINS`) وقيم `.env.example` أمثلة فقط.

**الخلاصة:** لا يمكن تحديد العنوان الحي من الملفات. العنوان المعتمد هو ما تحمله Replit Secrets الفعلية (لا أملك صلاحية الوصول إليها). للحسم افتح Secrets/Deployment في Replit وقارن `GOOGLE_REDIRECT_URI`.
بعد اختيار العنوان يجب أن يتطابق **حرفيًا**: `GOOGLE_REDIRECT_URI` = `https://<host>/api/auth/google/callback` مع **Authorized redirect URI** في Google Cloud، وأن تكون `APP_BASE_URL` و`NOVAMAIL_WEB_URL` = `https://<host>` و`ALLOWED_ORIGINS` تحتوي `https://<host>`. حدّث `index.html` (canonical/OG) إن رغبت.

## 3. متغيرات البيئة (أسماء فقط — لا تضع القيم في المستودع)

عند `NODE_ENV=production` يرفض الخادم الإقلاع برسالة `Production security configuration invalid: …` إذا نقص أي مما يلي (`artifacts/api-server/src/lib/production-config.ts`):

**دائمًا:** `DATABASE_URL` · `JWT_ACCESS_SECRET` · `JWT_REFRESH_SECRET` · `SESSION_IP_HASH_SECRET` · `WEBHOOK_ENCRYPTION_KEY` (64 hex أو base64 لـ32 بايت) · `APP_BASE_URL` (https) · `NOVAMAIL_WEB_URL` (https) · `ALLOWED_ORIGINS` (قائمة https بلا `*`) · `TRUST_PROXY` (0–10) · `REQUEST_BODY_LIMIT_BYTES`

> `scripts/start-production.sh` يصدّر الآن افتراضيات `NODE_ENV=production` و`TRUST_PROXY=1` و`REQUEST_BODY_LIMIT_BYTES=10485760` (مطابقة لافتراضيات `app.ts`)، وتتغلب عليها القيم الصريحة. أما الأسرار والعناوين فيجب أن تضبطها أنت.

**مشروطة بالأعلام:**

| الشرط | المتغيرات |
|-------|-----------|
| `ENABLE_GMAIL=true` | `GMAIL_TOKEN_ENCRYPTION_KEY` · `GOOGLE_CLIENT_ID` · `GOOGLE_CLIENT_SECRET` · `GOOGLE_REDIRECT_URI` |
| Gmail Push (الوارد الفوري) | `GMAIL_PUBSUB_OIDC_AUDIENCE` · `GMAIL_PUBSUB_SERVICE_ACCOUNT_EMAIL` · اختياري `GMAIL_PUBSUB_TOPIC_NAME` (الافتراضي: القيمة السابقة المكتوبة في الكود) |
| `ENABLE_2FA=true` | `TWO_FACTOR_ENCRYPTION_KEY` (hex، 32 حرفًا فأكثر) |
| `ENABLE_NOTIFICATIONS=true` | `NOTIFICATION_TOKEN_ENCRYPTION_KEY` (hex، 64 فأكثر) |
| `FCM_ENABLED=true` | `FCM_PROJECT_ID` · `FCM_SERVICE_ACCOUNT_JSON` |
| `WEB_PUSH_ENABLED=true` | `WEB_PUSH_VAPID_PUBLIC_KEY` · `WEB_PUSH_VAPID_PRIVATE_KEY` |
| `ATTACHMENT_SCANNING_ENABLED` (افتراضي السكربت `true`) | `CLAMAV_HOST` · `CLAMAV_PORT` (افتراضيات السكربت `127.0.0.1` و`3310`) |

اختياري: `URL_INTELLIGENCE_RATE_LIMIT_PER_MINUTE` (1–200، الافتراضي 20) سقف نداءات مزوّد استخبارات الروابط لكل مستخدم.

اختياري: `EXTERNAL_API_TIMEOUT_MS` (1000–120000، الافتراضي 20000) مهلة نداءات Google/Gemini (انظر FIX-18).

الأعلام المنطقية يجب أن تكون `true/false/1/0` وإلا يفشل الإقلاع. مزوّدا تحليل التهديدات واستخبارات الروابط اختياريان، لكن إن ضُبط أحد حقول المزوّد وجب ضبط المزوّد والعنوان والمفتاح (https، والمفتاح 16 حرفًا فأكثر). أما `ATTACHMENT_SANDBOX_*` فمخصص للـstaging فقط ويرفض الإقلاع الإنتاجي أي قيمة منه.
`NOVAMAIL_WEB_URL` يُستعمل أيضًا لإعادة التوجيه بعد OAuth.

## 4. إعدادات Replit الفعلية (من `.replit`)

- الوحدات: `nodejs-24`، `postgresql-16`، `python-base-3.13`؛ حزم nix تتضمن `clamav`.
- البناء: `pnpm --filter @workspace/api-server run build && pnpm --filter @workspace/novamail-web run build`
- التشغيل: `./scripts/start-production.sh` (autoscale، المنفذ المحلي 3000 ← الخارجي 80؛ الخادم يستمع على `PORT` أو 3000).
- الـAPI يخدم واجهة الويب المبنية من `artifacts/novamail-web/dist/public` في نفس المنشأ، ويحاول إيقاف التشغيل بأمان عند `SIGTERM`/`SIGINT`.
- **لا توجد خطوة ترحيل قاعدة بيانات تلقائية** (السكربت لا يستدعي Prisma). طبّق الترحيلات يدويًا: `pnpm run db:migrate:deploy` بعد أخذ نسخة احتياطية، وجرّبها أولًا على نسخة من القاعدة. لا تستعمل `prisma migrate dev` على قاعدة مشتركة.

## 5. خطوات التحقق المحلي قبل النشر (بالشبكة)

```bash
pnpm install --frozen-lockfile
pnpm run verify                 # typecheck + test:unit (jest) + build
pnpm run test:integration       # vitest (يشمل worker-shutdown.integration.test.ts الذي يشغّل build.mjs)
pnpm run db:validate
pnpm --dir artifacts/novamail-web run i18n:check
pnpm run v5:todos
pnpm run security:secrets
pnpm run check:imports          # يتوقع الآن فشلًا (9 حزم fontkit + 5 حزم eslint غير معلنة) حتى تُنفَّذ خطوة PDF أعلاه
pnpm audit --prod
pnpm run test:e2e               # يشمل tests/e2e/editor-html-xss.spec.ts (لا يحتاج خادمًا لكن يشغّل webServer الإعداد)
# الخطوة في CI: pnpm --dir lib/api-spec run codegen  ثم  git diff --exit-code -- lib/api-client-react/src lib/api-zod/src
```

ملاحظة عن خطوة codegen في CI: عدّلتُ `lib/api-client-react/src/custom-fetch.ts` و`index.ts` (ملفان يدويان؛ إعداد orval يُنظّف `generated/` فقط). لم أستطع تشغيل orval هنا، فتأكد أن الفرق يبقى نظيفًا.

## 6. Google Cloud (لم يُتحقق منه)

1. Authorized redirect URI يطابق `GOOGLE_REDIRECT_URI` حرفيًا؛ ونطاق Gmail مفعّل في شاشة الموافقة والمستخدمون المسموح لهم/حالة النشر مناسبة.
2. Pub/Sub: الـtopic الافتراضي `projects/novamail-504404/topics/novamail-gmail-events`. إن كان مشروعك مختلفًا اضبط `GMAIL_PUBSUB_TOPIC_NAME`. يجب منح `gmail-api-push@system.gserviceaccount.com` دور الناشر على الـtopic.
3. اشتراك push يوجّه إلى `https://<host>/api/gmail/push` مع OIDC: حساب الخدمة = `GMAIL_PUBSUB_SERVICE_ACCOUNT_EMAIL` والجمهور = `GMAIL_PUBSUB_OIDC_AUDIENCE`.
4. بعد FIX-02 لن يفشل ربط الحساب إن تعثّر إعداد المراقبة، لكن راقب سجل التحذير `Gmail push notifications could not be started`.
5. المراقبة (`watch`) لا تُجدَّد تلقائيًا (تنتهي بعد نحو 7 أيام بحسب توثيق Gmail)؛ الواجهة تستطلع كل 60 ثانية للحساب الأول فقط (انظر المشكلات المتبقية).

## 7. ClamAV

- `start-production.sh` يشغّل `clamd` على `127.0.0.1:3310` (`StreamMaxLength 60M`، `MaxFileSize 50M`) ويشغّل `freshclam` **فقط عند غياب قاعدة التواقيع**، وقاعدتها في `/tmp/zephyx-clamav` (مؤقتة): كل نسخة جديدة تنزّل التواقيع عند الإقلاع (تحتاج خروجًا إلى الإنترنت وتبطئ بدء التشغيل)، ولا تُحدَّث أثناء عمل النسخة. بسبب `set -e` يفشل الإقلاع إن فشل التنزيل.
- سلوك الكود (بالقراءة): الرفع **يفشل مغلقًا** (503) إن كان الفحص معطّلًا أو تعذّر الاتصال بـ`clamd`؛ وفي `NODE_ENV=development` فقط تُعاد النتيجة "نظيف" دون فحص.
- لم أستطع اختبار المحرك. اختبر: رفع ملف EICAR القياسي (يجب أن يُرفض)، ورفع ملف نصي عادي (يجب أن يُقبل)، وإيقاف `clamd` (يجب أن يرد 503). صيغة `clamdscan --ping 1 2` في السكربت لم تُتحقق.

## 8. تطبيق Flutter

```bash
cd mobile/novamail-flutter
flutter pub get
dart run build_runner build --delete-conflicting-outputs   # يُعيد توليد *.g.dart (بعد تعديل api_client.dart)
flutter analyze && flutter test
flutter build apk --release --dart-define=API_BASE_URL=https://<host>/api
```

`API_BASE_URL` يجب أن يكون `https` ويحتوي `/api` ولا يقبل `localhost`/`127.0.0.1`/`::1`/`10.0.2.2`. إن تُرك فارغًا يعمل التطبيق في وضع "Backend Not Configured". منذ FIX-03 صلاحية `INTERNET` موجودة في manifest الرئيسي.

## 9. فحوصات ما بعد النشر (smoke)

1. `GET /api/healthz` ثم نقطتا الجاهزية في `routes/health.ts` (`/health/live`, `/health/ready`).
2. تسجيل دخول/خروج وتجديد الرمز.
3. ربط Gmail كاملًا (حساب اختبار) ثم مزامنة صندوق الوارد؛ تحقق من وصول إشعارات push.
4. رفع ملف نصي عربي أكبر من 4 KB (حالة FIX-01) وملف EICAR.
5. تصدير تقرير الأمان PDF بعد إضافة الاعتماديات (وإلا يُتوقع 503).
6. فتح الواجهة وتأكد من تحميل الخطوط (لا مخالفات CSP في وحدة تحكم المتصفح).
7. (FIX-15) أرسل إلى حساب اختبار رسالة نصية موضوعها `<img src=x onerror=alert(1)>` ثم اضغط "رد" و"تمرير": يجب ألا يظهر تنبيه ويظهر النص مُرمَّزًا.
8. (FIX-14) سجّل webhook بعنوان `https://[::127.0.0.1]/hook`: يجب أن يُرفض بـ400.
9. (FIX-17) جرّب بحساب المدير الوحيد تخفيض دوره أو تعطيله: يجب أن يردّ 409.
10. (FIX-20) بحساب admin في منظمة، أضف بريد **المالك** بدور `member` عبر `POST /api/enterprise/:orgId/members`: يجب 400 `Owner membership cannot be changed through this endpoint` ويبقى المالك owner.
11. (FIX-21) سمِّ عضوًا `=1+1` ثم صدّر `reports.csv`: يجب أن تظهر الخلية `'=1+1` (نص لا صيغة).
12. (FIX-22/23) أعد فتح حادث محلول: يجب أن يصبح `resolvedAt` فارغًا؛ وعيّن `assignedTo` لمستخدم من خارج المنظمة: يجب 400.
13. (FIX-27) افتح رسالة HTML فيها `<img src="https://…">` مع تفعيل "حظر الصور الخارجية" (الافتراضي): لا يجب أن يظهر طلب شبكة إلى المضيف الخارجي في أدوات المتصفح؛ ثم عطّل الخيار في مركز الخصوصية وأعد فتحها: تُحمَّل الصورة.
14. بعد النشر ستبدأ الحملات الجديدة ببصمات مختلفة عن القديمة (FIX-25) — متوقع.
15. (FIX-28) سجّل جهازًا برمز دفع وهمي ثم أرسل بريدًا: يجب أن ينجح الإرسال ويُسجَّل تحذير `Push delivery failed`؛ وبرمز FCM منتهٍ (UNREGISTERED) يجب أن يُلغى الجهاز.
16. (FIX-29) أرسل رسالة طويلة بمعاينة مفعّلة: يجب ألا تتجاوز المعاينة 140 حرفًا والموضوع 100.
17. (FIX-34) بريد من `bank.co.uk` بـReturn-Path من `evil.co.uk`: يجب أن يُصنَّف الانتحال "high".
18. (FIX-35/36) افتح تحليل روابط لرسالة فيها 60 رابطًا سليمًا ورابط خبيث: يجب أن يظهر الخبيث أولًا؛ وأكثر من 20 طلبًا/دقيقة لنفس المستخدم يعيد 429 (`URL_INTELLIGENCE_RATE_LIMIT_PER_MINUTE`).
19. (FIX-37) أرسل 3 طلبات ذكاء اصطناعي يرفضها المزوّد (400/مفلترة) ثم طلبًا من مستخدم آخر: يجب أن ينجح الثاني (لا `AI_CIRCUIT_OPEN`).
20. (FIX-39) ابحث في صندوق الوارد بـ«غير مقروء» و«اجتماع» و«رسائل اليوم»: يجب أن تُطبَّق الفلاتر؛ و`after:2026-13-45` لا يُسقط الاستعلام.
21. (FIX-40/41) أنشئ قالبًا بنص أكبر من 200000 حرف: يجب 400؛ وافتح مساحة العمل لأول مرة بحساب جديد (طلبات متوازية): لا 500.
22. (FIX-42/44) `GET /api/enterprise/completion/not-a-uuid/quarantine` و`PATCH /api/enterprise/<orgId>/members/not-a-uuid`: يجب 400 (`Invalid organization id` / `Invalid member id`) لا 500.
23. (FIX-43) في نشر Docker/staging (nginx): طلب `/api/<أي مسار ينتهي بـ .png>` يجب أن يصل إلى الـAPI لا أن يعيد 404 من nginx؛ تحقق بعد `docker compose build` (لم يُشغَّل nginx هنا).

## 10. التراجع

احتفظ بنسخة النشر السابقة وبنسخة قاعدة البيانات قبل الترحيل. إن فشل الإقلاع بعد هذا الإصدار بسبب التحقق الإنتاجي فالرسالة تسرد المتغيرات الناقصة؛ **لا تُرجع `NODE_ENV` إلى غير production** لتجاوزها، لأن ذلك يعطّل الحماية (يمكنك مؤقتًا ضبط `NODE_ENV` صراحةً، لكنه يعيد السلوك غير الآمن السابق).
