# Zephyx Mail — Webhook Delivery V1

Implemented as an additive backend/worker feature. No Base URL, CI, or database reset changes.

## Included

- Dedicated BullMQ `webhook-delivery` queue.
- PostgreSQL `webhook_delivery_outbox` with independent retry/lease state.
- AES-256-GCM encrypted webhook secret using `WEBHOOK_ENCRYPTION_KEY`.
- Existing `secret_hash` retained for compatibility.
- Secret rotation endpoint: `POST /api/enterprise/:organizationId/webhooks/:webhookId/rotate-secret`.
- HTTPS + DNS/IP SSRF protection immediately before delivery.
- Request timeout, redirect blocking, retry/backoff, permanent 4xx handling, dead-letter state.
- `failureCount` and `lastDeliveryAt` updates on the webhook record.
- HMAC-SHA256 signing using the existing webhook-signature implementation.
- Delivery metrics in `/metrics` and Prometheus-style in-process counters.
- Worker and scheduler support for the dedicated queue.
- Delivery tests for encryption, SSRF, HTTPS enforcement, and retry classification.
- Existing webhooks without `secret_encrypted` are reported as `secretNeedsRotation` and are not delivered until rotated.

## Required production secret

Set `WEBHOOK_ENCRYPTION_KEY` to either:

- 64 hexadecimal characters (32 bytes), or
- a 32-byte base64 value.

Do not reuse `TWO_FACTOR_ENCRYPTION_KEY`.

## Migration

Migration:

`artifacts/api-server/prisma/migrations/20260920090000_webhook_delivery/migration.sql`

It is additive only. It adds `secret_encrypted` and creates the webhook delivery outbox table/indexes. It does not drop/reset existing data.

## Runtime flow

Audit event -> webhook subscription match -> PostgreSQL webhook outbox -> scheduler -> BullMQ `webhook-delivery` -> dedicated worker -> SSRF check -> signed HTTPS POST -> success/retry/dead-letter state.
