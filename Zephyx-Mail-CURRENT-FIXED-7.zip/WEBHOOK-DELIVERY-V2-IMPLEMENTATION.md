# Zephyx Mail — Webhook Delivery V2

This patch completes the Enterprise Webhook Delivery path without resetting the database or changing the application Base URL/CI.

## Included

- Dedicated `webhook-delivery` BullMQ queue and Worker.
- Independent PostgreSQL transactional outbox: `webhook_delivery_outbox`.
- Encrypted webhook secret storage using AES-256-GCM and `WEBHOOK_ENCRYPTION_KEY`.
- One-time secret return on create/rotate; legacy hash-only webhooks require rotation.
- Retry state, exponential backoff, lease recovery, max attempts and dead-letter state.
- Delivery through pinned HTTPS DNS resolution to reduce DNS-rebinding SSRF risk.
- Private, loopback, link-local, multicast, metadata and reserved destination blocking.
- Redirects are not followed.
- Bounded delivery timeout and graceful worker cancellation.
- Existing HMAC-SHA256 webhook signature utility is used for outbound requests.
- Delivery metrics and DB-backed outbox metrics.
- Secret-rotation API and Enterprise Security UI action for legacy webhooks.
- Tests for encryption, SSRF rules and retry classification.

## Required production secret

Set `WEBHOOK_ENCRYPTION_KEY` to either:

- 64 hexadecimal characters (32 bytes), or
- base64 encoding of exactly 32 bytes.

Do not reuse the 2FA/Gmail encryption keys.

## Database

The migration is additive. It adds `secret_encrypted` and `webhook_delivery_outbox` plus indexes/foreign keys. It does not reset or recreate the database.

## Existing webhooks

Existing webhooks created before encrypted-secret support contain only `secretHash`. Their original secret cannot be reconstructed. They must be rotated before delivery.
