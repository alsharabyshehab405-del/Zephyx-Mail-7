import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:novamail_flutter/core/network/api_client.dart';

DioException _dioError(int? status) {
  final options = RequestOptions(path: '/auth/refresh');
  return DioException(
    requestOptions: options,
    response: status == null ? null : Response<dynamic>(requestOptions: options, statusCode: status),
    type: status == null ? DioExceptionType.connectionError : DioExceptionType.badResponse,
  );
}

void main() {
  group('isRefreshTokenRejected', () {
    test('treats 400/401/403 from the refresh endpoint as a rejected session', () {
      for (final status in [400, 401, 403]) {
        expect(isRefreshTokenRejected(_dioError(status)), isTrue, reason: 'status $status');
      }
    });

    test('keeps the session on network errors, timeouts and server errors', () {
      expect(isRefreshTokenRejected(_dioError(null)), isFalse);
      for (final status in [429, 500, 502, 503]) {
        expect(isRefreshTokenRejected(_dioError(status)), isFalse, reason: 'status $status');
      }
      expect(isRefreshTokenRejected(StateError('Backend Not Configured')), isFalse);
      expect(isRefreshTokenRejected(const FormatException('bad payload')), isFalse);
    });

    test('drops the session when there is no refresh token at all', () {
      expect(isRefreshTokenRejected(StateError('No refresh token')), isTrue);
    });
  });
}
