#!/usr/bin/env bash
# Declares the runtime dependencies of the vendored fontkit bundle
# (artifacts/api-server/src/modules/enterprise/vendor/fontkit/main.cjs) for @workspace/api-server and updates
# pnpm-lock.yaml the supported way (`pnpm add`). Without them the security PDF export answers 503 because the bundle
# cannot load (restructure, brotli, clone, dfa, fast-deep-equal, tiny-inflate, unicode-properties, unicode-trie,
# @swc/helpers). Needs network access, pnpm and npm.
#
# The bundle carries no version number (it is Parcel output). Its release is therefore found by comparing the SHA-256 of the
# vendored file with dist/main.cjs of every published fontkit 2.x; the dependency ranges are then read from that very release
# (nothing is guessed or hard-coded) and verified against what the bundle actually require()s.
#
#   ./scripts/add-pdf-font-dependencies.sh                       # detect the release automatically
#   FONTKIT_VERSION=2.0.4 ./scripts/add-pdf-font-dependencies.sh # or name it (a hash mismatch is reported as a warning)
#
# Afterwards review and commit artifacts/api-server/package.json and pnpm-lock.yaml.
set -Eeuo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

command -v pnpm >/dev/null || { echo "pnpm is required (see packageManager in package.json)" >&2; exit 1; }
command -v npm >/dev/null || { echo "npm is required to download fontkit tarballs for the hash comparison" >&2; exit 1; }

VENDORED="artifacts/api-server/src/modules/enterprise/vendor/fontkit/main.cjs"
vendored_sha="$(sha256sum "$VENDORED" | cut -d' ' -f1)"
work="$(mktemp -d)"; trap 'rm -rf "$work"' EXIT

# Prints "match" when dist/main.cjs of fontkit@$1 is byte-identical to the vendored bundle.
bundle_matches() {
  local dir="$work/$1"; mkdir -p "$dir"
  ( cd "$dir" && npm pack "fontkit@$1" --silent >/dev/null 2>&1 && tar -xzf ./*.tgz package/dist/main.cjs ) || return 1
  [ "$(sha256sum "$dir/package/dist/main.cjs" | cut -d' ' -f1)" = "$vendored_sha" ]
}

if [ -z "${FONTKIT_VERSION:-}" ]; then
  echo "Detecting the fontkit release of the vendored bundle (sha256 ${vendored_sha}) ..."
  for candidate in $(node -e '
    const versions = JSON.parse(process.argv[1]);
    console.log(versions.filter((v) => /^2\.\d+\.\d+$/.test(v)).reverse().join("\n"));
  ' "$(pnpm view fontkit versions --json)"); do
    if bundle_matches "$candidate"; then FONTKIT_VERSION="$candidate"; break; fi
  done
  [ -n "${FONTKIT_VERSION:-}" ] || { echo "No published fontkit 2.x dist/main.cjs matches the vendored bundle (it may have been modified). Re-run with FONTKIT_VERSION=<closest release>." >&2; exit 1; }
  echo "The vendored bundle is byte-identical to fontkit@${FONTKIT_VERSION} dist/main.cjs."
elif bundle_matches "$FONTKIT_VERSION"; then
  echo "The vendored bundle is byte-identical to fontkit@${FONTKIT_VERSION} dist/main.cjs."
else
  echo "WARNING: the vendored bundle is NOT byte-identical to fontkit@${FONTKIT_VERSION}; the final import check decides whether the ranges suffice." >&2
fi

echo "Reading the declared dependencies of fontkit@${FONTKIT_VERSION} ..."
specs="$(node -e '
  const deps = JSON.parse(process.argv[1]);
  console.log(Object.entries(deps).map(([name, range]) => `${name}@${range}`).join("\n"));
' "$(pnpm view "fontkit@${FONTKIT_VERSION}" dependencies --json)")"

[ -n "$specs" ] || { echo "fontkit@${FONTKIT_VERSION} reports no dependencies; check the version." >&2; exit 1; }
echo "Adding to @workspace/api-server:"; echo "$specs" | sed 's/^/  /'

# shellcheck disable=SC2086
pnpm --filter @workspace/api-server add $specs

echo "Verifying that everything the vendored bundle require()s is now declared ..."
node scripts/check-undeclared-imports.mjs artifacts/api-server
echo "OK. Commit artifacts/api-server/package.json and pnpm-lock.yaml, then run the api-server tests and test the PDF export."
