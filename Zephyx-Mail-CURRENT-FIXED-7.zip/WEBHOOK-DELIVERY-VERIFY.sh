#!/usr/bin/env bash
set -euo pipefail

echo '== Zephyx Webhook Delivery verification V3 =='
echo '1/5 Prisma client generation (source/schema sync)'
pnpm --dir artifacts/api-server run prisma:generate

echo '2/5 Typecheck'
pnpm typecheck

echo '3/5 Webhook unit tests'
pnpm --dir artifacts/api-server run test:run -- src/lib/webhook-delivery.test.ts src/lib/webhook-signature.test.ts

echo '4/5 Prisma schema validation'
pnpm --dir artifacts/api-server exec prisma validate --schema prisma/schema.prisma

echo '5/5 Scheduler/Webhook integration check (requires PostgreSQL + Redis)'
pnpm --dir artifacts/api-server run test:run -- src/lib/scheduler.integration.test.ts

echo 'Verification completed. No database reset or migration was executed.'
