#!/usr/bin/env node
// Reports bare imports/requires that a workspace package uses but does not declare in its own package.json.
// With pnpm's strict node_modules layout such an import resolves in nobody's else's tree, so it fails at build or
// run time (example: the vendored fontkit bundle requires `restructure`, `brotli`, ... which no package declares).
// Zero dependencies; read-only. Usage: node scripts/check-undeclared-imports.mjs [package-dir ...]
// e.g. `node scripts/check-undeclared-imports.mjs artifacts/api-server` limits the check to that package. Exit 1 if anything is undeclared.
import { builtinModules } from "node:module";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const skipDirs = new Set(["node_modules", "dist", "build", ".git", ".dart_tool", "coverage", "test-results", "playwright-report"]);
const sourceExt = /\.(?:[cm]?[jt]sx?)$/;
const builtins = new Set(builtinModules.map((name) => name.replace(/^node:/, "")));

function packageDirs() {
  const dirs = [root];
  for (const group of ["artifacts", "lib"]) {
    const base = path.join(root, group);
    if (!existsSync(base)) continue;
    for (const entry of readdirSync(base)) if (existsSync(path.join(base, entry, "package.json"))) dirs.push(path.join(base, entry));
  }
  return dirs;
}

function* walk(dir, isRoot) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (skipDirs.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      // the root package owns only its top-level tooling files; workspace packages are scanned on their own
      if (isRoot && ["artifacts", "lib", "mobile", "docs", "deploy", "tests"].includes(entry.name)) continue;
      yield* walk(full, isRoot);
    } else if (sourceExt.test(entry.name) && !entry.name.endsWith(".d.ts")) yield full;
  }
}

// A module specifier never contains whitespace, quotes, colons or brackets; this avoids matching prose inside strings.
const specifier = "([A-Za-z0-9@_./~+-]+)";
const patterns = [new RegExp(`\\bfrom\\s*["']${specifier}["']`, "g"), new RegExp(`\\bimport\\s*\\(\\s*["']${specifier}["']\\s*\\)`, "g"), new RegExp(`\\brequire\\s*\\(\\s*["']${specifier}["']\\s*\\)`, "g"), new RegExp(`^\\s*import\\s+["']${specifier}["']`, "gm")];
const packageName = (spec) => (spec.startsWith("@") ? spec.split("/").slice(0, 2).join("/") : spec.split("/")[0]);

const only = process.argv.slice(2).map((value) => value.replace(/\/$/, ""));
let problems = 0;
for (const dir of packageDirs()) {
  if (only.length && !only.includes(path.relative(root, dir) || ".")) continue;
  const manifest = JSON.parse(readFileSync(path.join(dir, "package.json"), "utf8"));
  const declared = new Set([manifest.name, ...["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"].flatMap((key) => Object.keys(manifest[key] ?? {}))]);
  const missing = new Map();
  for (const file of walk(dir, dir === root)) {
    const text = readFileSync(file, "utf8");
    for (const pattern of patterns) {
      for (const match of text.matchAll(pattern)) {
        const line = text.slice(text.lastIndexOf("\n", match.index) + 1, text.indexOf("\n", match.index) === -1 ? undefined : text.indexOf("\n", match.index)).trim();
        if (line.startsWith("//") || line.startsWith("*") || line.startsWith("/*")) continue;
        const spec = match[1];
        if (/^(?:\.|\/|node:|data:|virtual:|https?:|@\/|@assets\/|~)/.test(spec) || builtins.has(packageName(spec))) continue;
        const name = packageName(spec);
        if (declared.has(name)) continue;
        if (!missing.has(name)) missing.set(name, new Set());
        missing.get(name).add(path.relative(root, file));
      }
    }
  }
  if (missing.size) {
    problems += missing.size;
    console.log(`\n${path.relative(root, dir) || "."} (${manifest.name}) imports packages it does not declare:`);
    for (const [name, files] of [...missing].sort()) console.log(`  - ${name}  <- ${[...files].slice(0, 2).join(", ")}${files.size > 2 ? ` (+${files.size - 2})` : ""}`);
  }
}
console.log(problems ? `\n${problems} undeclared import(s) found.` : "No undeclared imports found.");
process.exit(problems ? 1 : 0);
