# الملفات الجديدة والمعدلة والمحذوفة — Zephyx Mail

مولَّدة بالأمر diff -rq (تاريخ 2026-10-26). ملف CHANGED_FILES.md نفسه ضمن الجديد. لم يُحذف أي ملف مصدر ولم تُغيَّر نسخ اعتماديات ولم يُحدَّث pnpm-lock.yaml (لا شبكة).

## أ) النسخة FIXED-7 مقارنةً بالأرشيف الأصلي Zephyx-Mail-CURRENT-CLEAN.zip

#### معدَّلة (72)

- `.env.example`
- `artifacts/api-server/build.mjs`
- `artifacts/api-server/src/app.ts`
- `artifacts/api-server/src/lib/attachment-security.ts`
- `artifacts/api-server/src/lib/external-adapters.ts`
- `artifacts/api-server/src/lib/webhook-delivery.ts`
- `artifacts/api-server/src/lib/webhook-ssrf.ts`
- `artifacts/api-server/src/modules/admin/admin.service.ts`
- `artifacts/api-server/src/modules/ai/ai-policy.ts`
- `artifacts/api-server/src/modules/ai/ai.service.ts`
- `artifacts/api-server/src/modules/emails/emails.service.ts`
- `artifacts/api-server/src/modules/enterprise/enterprise.controller.ts`
- `artifacts/api-server/src/modules/enterprise/enterprise.service.ts`
- `artifacts/api-server/src/modules/enterprise/global-completion.controller.ts`
- `artifacts/api-server/src/modules/enterprise/global-completion.service.ts`
- `artifacts/api-server/src/modules/gmail/gmail.service.ts`
- `artifacts/api-server/src/modules/notifications/notifications.controller.ts`
- `artifacts/api-server/src/modules/notifications/notifications.service.ts`
- `artifacts/api-server/src/modules/privacy/privacy.controller.ts`
- `artifacts/api-server/src/modules/productivity/productivity.service.ts`
- `artifacts/api-server/src/modules/security/ai-phishing.service.ts`
- `artifacts/api-server/src/modules/security/security-feedback.service.ts`
- `artifacts/api-server/src/modules/security/threat-analysis-provider.ts`
- `artifacts/api-server/src/modules/security/threat-protection.service.ts`
- `artifacts/api-server/src/modules/security/url-intelligence.service.ts`
- `artifacts/api-server/src/routes/chat.ts`
- `artifacts/novamail-web/nginx.conf`
- `artifacts/novamail-web/nginx.staging.conf`
- `artifacts/novamail-web/scripts/validate-localization.mjs`
- `artifacts/novamail-web/src/components/compose-modal.tsx`
- `artifacts/novamail-web/src/components/email-detail.tsx`
- `artifacts/novamail-web/src/hooks/use-i18n.tsx`
- `artifacts/novamail-web/src/locales/ar/settings.json`
- `artifacts/novamail-web/src/locales/de/enterprise.json`
- `artifacts/novamail-web/src/locales/de/settings.json`
- `artifacts/novamail-web/src/locales/en/settings.json`
- `artifacts/novamail-web/src/locales/en/workspace.json`
- `artifacts/novamail-web/src/locales/es/enterprise.json`
- `artifacts/novamail-web/src/locales/es/settings.json`
- `artifacts/novamail-web/src/locales/es/workspace.json`
- `artifacts/novamail-web/src/locales/fr/enterprise.json`
- `artifacts/novamail-web/src/locales/fr/settings.json`
- `artifacts/novamail-web/src/locales/hi/enterprise.json`
- `artifacts/novamail-web/src/locales/hi/settings.json`
- `artifacts/novamail-web/src/locales/id/enterprise.json`
- `artifacts/novamail-web/src/locales/id/settings.json`
- `artifacts/novamail-web/src/locales/it/enterprise.json`
- `artifacts/novamail-web/src/locales/it/settings.json`
- `artifacts/novamail-web/src/locales/ja/enterprise.json`
- `artifacts/novamail-web/src/locales/ja/settings.json`
- `artifacts/novamail-web/src/locales/ko/enterprise.json`
- `artifacts/novamail-web/src/locales/ko/settings.json`
- `artifacts/novamail-web/src/locales/pt/enterprise.json`
- `artifacts/novamail-web/src/locales/pt/settings.json`
- `artifacts/novamail-web/src/locales/ru/enterprise.json`
- `artifacts/novamail-web/src/locales/ru/settings.json`
- `artifacts/novamail-web/src/locales/tr/enterprise.json`
- `artifacts/novamail-web/src/locales/tr/settings.json`
- `artifacts/novamail-web/src/locales/ur/enterprise.json`
- `artifacts/novamail-web/src/locales/ur/settings.json`
- `artifacts/novamail-web/src/locales/zh-CN/enterprise.json`
- `artifacts/novamail-web/src/locales/zh-CN/settings.json`
- `docker-compose.yml`
- `lib/api-client-react/src/custom-fetch.ts`
- `lib/api-client-react/src/index.ts`
- `mobile/novamail-flutter/README.md`
- `mobile/novamail-flutter/android/app/src/main/AndroidManifest.xml`
- `mobile/novamail-flutter/lib/core/network/api_client.dart`
- `mobile/novamail-flutter/lib/features/email/data/email_repository.dart`
- `package.json`
- `scripts/start-production.sh`
- `scripts/validate-v5-todos.mjs`

#### جديدة (53)

- `artifacts/api-server/src/lib/attachment-security.test.ts`
- `artifacts/api-server/src/lib/clamav-instream.test.ts`
- `artifacts/api-server/src/lib/clamav-instream.ts`
- `artifacts/api-server/src/lib/csv-safe.test.ts`
- `artifacts/api-server/src/lib/csv-safe.ts`
- `artifacts/api-server/src/lib/http-timeout.test.ts`
- `artifacts/api-server/src/lib/http-timeout.ts`
- `artifacts/api-server/src/lib/rate-window.test.ts`
- `artifacts/api-server/src/lib/rate-window.ts`
- `artifacts/api-server/src/lib/webhook-ssrf.test.ts`
- `artifacts/api-server/src/modules/ai/ai-errors.test.ts`
- `artifacts/api-server/src/modules/ai/ai-errors.ts`
- `artifacts/api-server/src/modules/ai/ai-policy-health.test.ts`
- `artifacts/api-server/src/modules/ai/ai-thread.test.ts`
- `artifacts/api-server/src/modules/ai/ai-thread.ts`
- `artifacts/api-server/src/modules/enterprise/campaign-fingerprint.test.ts`
- `artifacts/api-server/src/modules/enterprise/campaign-fingerprint.ts`
- `artifacts/api-server/src/modules/enterprise/membership-rules.test.ts`
- `artifacts/api-server/src/modules/enterprise/membership-rules.ts`
- `artifacts/api-server/src/modules/enterprise/policy-decision.test.ts`
- `artifacts/api-server/src/modules/enterprise/policy-decision.ts`
- `artifacts/api-server/src/modules/enterprise/uuid-param.test.ts`
- `artifacts/api-server/src/modules/enterprise/uuid-param.ts`
- `artifacts/api-server/src/modules/gmail/gmail-pubsub.test.ts`
- `artifacts/api-server/src/modules/gmail/gmail-pubsub.ts`
- `artifacts/api-server/src/modules/notifications/push-rules.test.ts`
- `artifacts/api-server/src/modules/notifications/push-rules.ts`
- `artifacts/api-server/src/modules/productivity/productivity-limits.test.ts`
- `artifacts/api-server/src/modules/productivity/productivity-limits.ts`
- `artifacts/api-server/src/modules/productivity/workspace-query.test.ts`
- `artifacts/api-server/src/modules/productivity/workspace-query.ts`
- `artifacts/api-server/src/modules/security/domain-utils.test.ts`
- `artifacts/api-server/src/modules/security/domain-utils.ts`
- `artifacts/api-server/src/modules/security/provider-http.test.ts`
- `artifacts/api-server/src/modules/security/provider-http.ts`
- `artifacts/api-server/src/modules/security/redaction.test.ts`
- `artifacts/api-server/src/modules/security/redaction.ts`
- `artifacts/api-server/src/modules/security/url-priority.test.ts`
- `artifacts/api-server/src/modules/security/url-priority.ts`
- `artifacts/novamail-web/src/lib/editor-html.ts`
- `artifacts/novamail-web/src/lib/i18n-flatten.ts`
- `artifacts/novamail-web/src/lib/remote-images.ts`
- `docs/BUG_FIX_REPORT.md`
- `docs/CHANGED_FILES.md`
- `docs/COMPREHENSIVE_AUDIT_REPORT.md`
- `docs/DEPLOYMENT_READINESS.md`
- `docs/TEST_RESULTS.md`
- `mobile/novamail-flutter/test/android_manifest_test.dart`
- `mobile/novamail-flutter/test/api_client_refresh_policy_test.dart`
- `mobile/novamail-flutter/test/html_from_plain_text_test.dart`
- `scripts/add-pdf-font-dependencies.sh`
- `scripts/check-undeclared-imports.mjs`
- `tests/e2e/editor-html-xss.spec.ts`

#### محذوفة (0)

لا شيء.

## ب) تغييرات هذا الجزء فقط (FIXED-7 مقارنةً بـ Zephyx-Mail-CURRENT-FIXED-6.zip)

#### معدَّلة (5)

- `docs/BUG_FIX_REPORT.md`
- `docs/CHANGED_FILES.md`
- `docs/COMPREHENSIVE_AUDIT_REPORT.md`
- `docs/TEST_RESULTS.md`
- `mobile/novamail-flutter/lib/core/network/api_client.dart`

#### جديدة (0)

لا شيء.

#### محذوفة (0)

لا شيء.

