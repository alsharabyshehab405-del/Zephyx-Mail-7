#!/usr/bin/env bash
set -Eeuo pipefail

# This script only starts the deployed server. NODE_ENV was never set here (nor in .replit), so a deployment that
# did not define it silently skipped validateProductionSecrets(), CSP/HSTS, the strict CORS allow-list and could fall
# back to the development JWT secrets that ship in the repository. Default it to production (an explicit value wins).
export NODE_ENV="${NODE_ENV:-production}"
# Production validation requires these to be set explicitly; the defaults below equal the defaults hard-coded in app.ts,
# so exporting them does not change runtime behaviour.
export TRUST_PROXY="${TRUST_PROXY:-1}"
export REQUEST_BODY_LIMIT_BYTES="${REQUEST_BODY_LIMIT_BYTES:-10485760}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CLAMAV_DIR="${CLAMAV_RUNTIME_DIR:-/tmp/zephyx-clamav}"
CLAMAV_DB_DIR="$CLAMAV_DIR/db"
CLAMAV_LOG_DIR="$CLAMAV_DIR/log"
CLAMAV_PORT="${CLAMAV_PORT:-3310}"
CLAMAV_USER="$(id -un)"

mkdir -p "$CLAMAV_DB_DIR" "$CLAMAV_LOG_DIR"
chmod 700 "$CLAMAV_DIR" "$CLAMAV_DB_DIR" "$CLAMAV_LOG_DIR"

CLAMD_CONF="$CLAMAV_DIR/clamd.conf"
FRESHCLAM_CONF="$CLAMAV_DIR/freshclam.conf"

cat > "$CLAMD_CONF" <<CONF
DatabaseDirectory $CLAMAV_DB_DIR
LogFile $CLAMAV_LOG_DIR/clamd.log
LogTime yes
PidFile $CLAMAV_DIR/clamd.pid
Foreground yes
User $CLAMAV_USER
TCPSocket $CLAMAV_PORT
TCPAddr 127.0.0.1
StreamMaxLength 60M
MaxScanSize 50M
MaxFileSize 50M
MaxRecursion 16
MaxFiles 100
ScanPE yes
ScanELF yes
ScanOLE2 yes
ScanPDF yes
ScanHTML yes
ScanArchive yes
CONF

cat > "$FRESHCLAM_CONF" <<CONF
DatabaseDirectory $CLAMAV_DB_DIR
UpdateLogFile $CLAMAV_LOG_DIR/freshclam.log
LogTime yes
Checks 24
DatabaseMirror database.clamav.net
CONF

if [[ ! -s "$CLAMAV_DB_DIR/main.cvd" && ! -s "$CLAMAV_DB_DIR/main.cld" ]]; then
  freshclam --config-file="$FRESHCLAM_CONF"
fi

clamd --config-file="$CLAMD_CONF" --foreground=yes &
CLAMD_PID=$!

cleanup() {
  kill "$CLAMD_PID" 2>/dev/null || true
  wait "$CLAMD_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

READY=0

for _ in $(seq 1 90); do
  if ! kill -0 "$CLAMD_PID" 2>/dev/null; then
    echo "ERROR: ClamAV daemon exited before becoming ready" >&2
    exit 1
  fi

  if clamdscan --config-file="$CLAMD_CONF" --ping 1 2 >/dev/null 2>&1; then
    READY=1
    break
  fi

  sleep 1
done

if [[ "$READY" != "1" ]]; then
  echo "ERROR: ClamAV daemon did not become ready" >&2
  exit 1
fi

export ATTACHMENT_SCANNING_ENABLED="${ATTACHMENT_SCANNING_ENABLED:-true}"
export CLAMAV_HOST="${CLAMAV_HOST:-127.0.0.1}"
export CLAMAV_PORT

echo "ClamAV is ready on ${CLAMAV_HOST}:${CLAMAV_PORT}"

exec pnpm --filter @workspace/api-server run start
