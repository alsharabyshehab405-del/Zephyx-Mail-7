import 'package:flutter_test/flutter_test.dart';
import 'package:novamail_flutter/features/email/data/email_repository.dart';

void main() {
  group('htmlFromPlainText', () {
    test('escapes markup characters typed by the user', () {
      expect(
        htmlFromPlainText('if a < b & c > d "q" it\'s'),
        '<p>if a &lt; b &amp; c &gt; d &quot;q&quot; it&#039;s</p>',
      );
      expect(htmlFromPlainText('<img src=x onerror=alert(1)>'), '<p>&lt;img src=x onerror=alert(1)&gt;</p>');
    });

    test('keeps line breaks and Arabic text', () {
      expect(htmlFromPlainText('سطر 1\nسطر 2'), '<p>سطر 1<br/>سطر 2</p>');
    });
  });
}
