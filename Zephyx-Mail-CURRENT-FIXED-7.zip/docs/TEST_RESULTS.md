# نتائج الاختبارات والفحوصات الفعلية — Zephyx Mail

تاريخ التنفيذ: 2026-10-15 · النسخة المفحوصة: المشروع بعد الإصلاحات (قورنت بالنسخة الأصلية المستخرجة من `Zephyx-Mail-CURRENT-CLEAN.zip`)

## 1. بيئة التنفيذ وما تعذّر بسببها

| العنصر | الحالة |
|--------|--------|
| Node.js | v22.22.2 (المشروع يستهدف Node 24 في `.replit`) |
| TypeScript | 6.0.3 عام (المشروع يثبّت ~5.9) — استُخدم لتحليل الصياغة والأنواع الجزئي فقط |
| esbuild | مُرفق مع `tsx` (0.27.x) وليس الإصدار المثبّت في المشروع |
| الشبكة | **غير متاحة**: `Could not resolve host: registry.npmjs.org` ⇒ لا `pnpm install` ولا `node_modules` |
| pnpm / Postgres / ClamAV / Flutter+Dart / Docker | غير مثبّتة |

> أي فشل ناتج عن هذه القيود **ليس** خطأً برمجيًا مؤكدًا في المشروع، وهو مُصنَّف أدناه "تعذّر بسبب البيئة".

## 2. فحوصات نُفِّذت فعليًا — نجحت (على النسخة النهائية)

| # | الفحص | النتيجة الفعلية |
|---|-------|-----------------|
| 1 | تحليل الصياغة (TypeScript compiler API) لكل ملفات TS/TSX/JS/MJS/CJS | 685 ملفًا، **0 خطأ صياغة** |
| 2 | حل الاستيرادات النسبية | 1032 استيرادًا، **0 غير محلول** |
| 3 | اتساق `pnpm-lock.yaml` مع كل `package.json` (7 importers) + `catalog:` + `workspace:` + `overrides` | **0 مشكلة**، `overrides` متطابقة |
| 4 | حزمة esbuild لنقاط دخول الـAPI (`index`/`worker`/`scheduler`) بالحزم الخارجية | نجحت (تؤكد سلامة رسم الوحدات الداخلية؛ لا تتحقق من الأنواع) |
| 5 | حزمة esbuild لواجهة الويب (`src/main.tsx`) | نجحت (بنفس القيد) |
| 6 | `bash -n` لكل سكربتات sh | 6 ملفات، 0 فشل |
| 7 | `py_compile` لسكربتات Python | 3 ملفات، 0 فشل |
| 8 | `node --check` لسكربتات Node (`scripts/`, `api-server/scripts`, `build.mjs`, …) | 16 ملفًا، 0 فشل |
| 9 | تحليل JSON / YAML | 413 JSON و11 YAML، **0 فشل** |
| 10 | فحص الأسرار الرسمي `scripts/scan-secrets.mjs` (داخل نسخة git مؤقتة لأن الأرشيف بلا `.git`) | `Secret scan passed for 1360 tracked files` |
| 11 | `scripts/validate-staging-env.mjs .env.staging.example` | نجح (وضع المخطط/المثال فقط) |
| 12 | `i18n:check` (مدقق التوطين الرسمي) | **نجح**: 15 لغة، 26 namespace، 933 مفتاحًا إنجليزيًا |
| 13 | `v5:todos` | **نجح** (exit 0) |
| 14 | جامع قواعد التوطين الكامل (كل اللغات، كل القواعد) | 0 مشكلة |
| 15 | اختبارات الانحدار الجديدة (99 اختبارًا في 21 ملفًا: مرفقات UTF-8، Pub/Sub، SSRF، مهلة HTTP، العضوية والحوادث، CSV، بصمة الحملات، قرار السياسات، الإشعارات، ClamAV، التنقية، النطاقات، أولوية الروابط، المعدّل، أخطاء/خيوط/قاطع الذكاء الاصطناعي، استعلام الإنتاجية ومدقِّقاتها، `requireUuidParam`) عبر harness متوافق مع vitest | **99 نجحت، 0 فشلت** |
| 16 | فحص `INTERNET` في manifest الرئيسي لـAndroid (XML) | موجودة |
| 17 | فحص الأنواع الجزئي (أنواع الحزم الخارجية مُستبدَلة بـ`any`) مقارنةً بخط الأساس | API: 705 → 700، الويب: 2352 → 2352. **6 تشخيصات جديدة كلها من ضجيج الاستبدال المؤقت** (`tx`/`device`/`row` implicitly any لأن `db` غير مثبّت، و`accessToken` unknown لأن `JWT` غير مثبّت)، واختفى بعضها بسبب إعادة الهيكلة؛ لا يوجد تشخيص أنواع حقيقي جديد |
| 18 | مواصفة Playwright `tests/e2e/editor-html-xss.spec.ts` (6 اختبارات) في **Chromium حقيقي** بمشغّل Playwright الحقيقي (إصدار عام 1.56، لا المثبّت 1.55.1) | **6 نجحت** على الكود المصحح |
| 19 | سكربت التحقق من كل الإصلاحات السابقة على الملفات الفعلية (27 فحصًا) | 27/27 (بعد تصحيح فحصين معيبين في السكربت نفسه، لا في المشروع: مطابقة ترجمة تركية بأحرف كبيرة، وتعليقات في الكود تذكر المسار) |
| 20 | `scripts/check-undeclared-imports.mjs` (جديد) على كل الحزم | يُبلغ بـ**14** استيرادًا غير معلن (9 fontkit + 5 eslint) — مطابق للتحليل السابق، وبلا إيجابيات كاذبة بعد تضييق التعبير |
| 21 | تحليل توافق الإصدارات من الملفات الفعلية | Node 24 في `.replit`/CI/Docker؛ pnpm 11.21.0 موحّد؛ `prisma` و`@prisma/client` و`@prisma/adapter-pg` كلها 7.9.1؛ لا نسخ مكررة لـreact/zod/drizzle/typescript؛ 0 حزمة تستثني Node 22/24 عبر `engines` |
| 22 | مقارنة متغيرات البيئة المقروءة في الكود بـ`.env.example`/compose/الوثائق | 129 اسمًا مقروءًا، 33 غير موثّق في أي مكان؛ قبل الإصلاح غاب `WEBHOOK_ENCRYPTION_KEY` (مطلوب عند الإقلاع الإنتاجي) عن `.env.example`؛ لا قيم تشبه الأسرار في ملفات `.env*.example` |
| 23 | `scripts/add-pdf-font-dependencies.sh` | `bash -n` ينجح؛ مساراه الآمنان للفشل (بلا `FONTKIT_VERSION`، بلا pnpm) يخرجان بـ1 برسالة واضحة. **المسار الرئيسي لم يُشغَّل (لا شبكة)** |
| 24 | اختبارات الجزء الرابع الجديدة: `membership-rules` (7)، `csv-safe` (3)، `campaign-fingerprint` (4)، `policy-decision` (7) | **21 نجحت** (ضمن الـ43). تجربة مباشرة: بصمة الدالة الأصلية لنفس الحملة بمسافات مختلفة **مختلفة**، والمصححة **متطابقة**؛ و`csvEscape` الأصلية تترك `=1+1`/`@SUM(1+1)`/`-2+3`/`+cmd|x` كما هي والمصححة تسبقها بـ`'` |
| 25 | مواصفة Playwright `editor-html-xss.spec.ts` (Chromium) | 6 نجحت (أعيد تشغيلها على النسخة النهائية) |
| 26 | **قبل/بعد على الكود الأصلي (من أرشيف FIXED-4)**: (أ) مرسِل ClamAV الأصلي أمام clamd صارم → يرسل `zINSTREAM\0` حرفيًا فيردّ الخادم `UNKNOWN COMMAND` ويفشل الفحص؛ المصحح يرسل NUL فيمرّ. (ب) تنقية `redactedText` الأصلية تُخرج `$1: [redacted]` والمصححة `password: [redacted]`. (ج) `registrableDomain`: `bank.co.uk` و`evil.co.uk` كلاهما `co.uk` (لا كشف) → المصحح يكشف. (د) قاطع الذكاء الاصطناعي: بعد 3 طلبات مرفوضة من مستخدم A يعيد `AI_CIRCUIT_OPEN` للمستخدم B → المصحح يخدم B. (هـ) `parseWorkspaceQuery` الأصلي يعيد `[]` لـ«غير مقروء» و«اجتماع الغد» و«رسائل اليوم»، و`from:حاد` لـ«مرض مزمن حاد»، و`after:2026-13-45` فلترًا → المصحح يعيد الصحيح | الأصل يفشل والمصحح ينجح في الحالات الخمس (نُفِّذت فعليًا) |
| 27 | R26/R17/R33: `requireUuidParam` (اختباران: معرّفات صالحة بما فيها nil وأحرف كبيرة تمرّ، و10 قيم سيئة تعطي 400 `Invalid organization id`)؛ ومحاكاة اختيار مواقع nginx للإعدادين | نجحت؛ المحاكاة: `/api/users/avatar.png` من `~* \\.(js|css|png|…` (قبل) إلى `^~ /api/` (بعد)، و`/api/emails/attachments/abc` و`/assets/app.js` دون تغيير. **المحاكاة ليست تشغيل nginx** |
| 28 | **فحص مستقل لأرشيف FIXED-6 كما سُلّم**: تحقق البصمة وسلامة الضغط، استخراج جديد مطابق لشجرة العمل، إعادة كل الفحوصات | نجح كله بنفس الأرقام (685 ملفًا، 1032 استيرادًا، 99 اختبارًا، 6 في Chromium، فحص الأسرار على 1360 ملفًا، 27/27 للإصلاحات السابقة) |
| 29 | توافق التعديلات مع اختبارات المشروع **بالقراءة والتنفيذ الجزئي**: `parseWorkspaceQuery` الحقيقي على الاستعلامات الأربعة المُثبَتة في `api.test.ts` (1458 و1548 و1566 و1577)؛ و`resolveAccountScope` يعالج `"all"`/`"local"` قبل `assertUuid`؛ واختبارات الإشعارات (معرّف جهاز UUID، `eventId` نصّي، حذف مستخدم آخر ⇒ 204)؛ و`enterprise.foundation.test.ts` لا يعتمد على نص المصدر المعدَّل | 4/4 PASS للاستعلامات؛ الباقي سلامة بالقراءة (**لم تُشغَّل ملفات اختبار المشروع الأصلية**) |
| 30 | ضابط سلبي: الفحص الجزئي للأنواع يكشف اسمًا غير معرّف (TS2304) ويؤكد أن `now` معرّف في `registerDevice` وأن `sanitizeQueueError` موجود | تأكد |
| 31 | استيرادات مواصفات e2e (الأداة تتجاوز `tests/`) مقابل `package.json` بالجذر؛ واستيرادات اختبارات Dart الجديدة مقابل اسم الحزمة `novamail_flutter` | لا استيراد غير معلن؛ وفحص Flutter الساكن بلا مشكلات بعد FIX-45 |

**حدود البند 15:** vitest غير قابل للتثبيت، فشُغِّلت ملفات الاختبار نفسها عبر harness صغير كتبتُه (`describe/it/expect` بمطابقات `toBe/toEqual/toBeNull/toBeGreaterThan/toThrow/not`) ومُرِّر `vitest` إليه عبر `tsconfig paths`. هذا **ليس** تشغيل vitest الحقيقي.

**حدود البند 17:** التشخيصات المتبقية (705/2352) كلها ناتجة عن غياب أنواع Express/Node/Prisma/React/cva في هذه البيئة (صُنِّفت يدويًا)، فهذا الفحص لا يُثبت خلو المشروع من أخطاء الأنواع؛ دوره الوحيد كشف **تراجعات** سببتها تعديلاتي. ضابط سلبي أثبت أنه يرفض اسمًا غير موجود مستوردًا من حزمة العميل المحلية (`TS2305`).

## 3. فحوصات فشلت فعليًا على النسخة الأصلية ثم نجحت بعد الإصلاح

| الفحص | الأصلية | النهائية |
|-------|---------|----------|
| `v5:todos` (`node scripts/validate-v5-todos.mjs`) | **exit 1** — `locales/es|pt/workspace.json:187` | exit 0 |
| `i18n:check` (`validate-localization.mjs`) | **exit 1** — `en/ai.json/languages: empty or non-string value` (ثم، بعد إصلاح المدقق، `es/enterprise.json` ينقصه 3 مفاتيح؛ المجموع 13 لغة) | exit 0 |
| إعادة إنتاج رفض نص عربي أكبر من 4 KB (الوحدة الحقيقية `attachment-security.ts` عبر `tsx`) | رُفضت حالتان من 6 | قُبلت الست؛ ضوابط سلبية (UTF-8 غير صالح/NUL/`MZ`/فارغ) ما زالت تُرفض |
| اختبار `attachment-security.test.ts` الجديد | **3 من 5 فشلت** على الكود الأصلي | 5 من 5 نجحت |
| تحليل مسارات `vendor/` و`assets/` نسبةً إلى `dist/index.mjs` | `MODULE_NOT_FOUND` + الخطوط مفقودة | تُحلّ بعد خطوة النسخ الجديدة في `build.mjs` |
| فحص `INTERNET` في manifest | `uses-permission = []` | `['android.permission.INTERNET']` |
| بحث `ai.tones.professional` في 15 لغة (تسطيح الواجهة) | `undefined` (الدالة القديمة) | 45/45 بحثًا يُحلّ |
| اختبارات `webhook-ssrf.test.ts` الجديدة (5) | **3 فشلت** على الوحدة الأصلية | 5 نجحت |
| فحص حارس SSRF على 14 عنوانًا (`tsx`) | `[::127.0.0.1]`, `[::169.254.169.254]`, `[64:ff9b::a9fe:a9fe]`, `[2002:a9fe:a9fe::1]` وغيرها **ALLOWED** | كلها blocked؛ العناوين العامة ما زالت مسموحة |
| دوال محرر الرد الأصلية في Chromium (حمولات `img onerror`, `details ontoggle`, `iframe srcdoc`, `input autofocus`, ورد مقتبس) | **نُفِّذ سكربت** عبر `innerHTML` (5 حالات) وعبر `stripHtml` (3 حالات) | صفر تنفيذ؛ 13/13 فحصًا وظيفيًا (تنسيق/RTL/روابط) |
| مواصفة Playwright نفسها على الدوال الأصلية | **6 فشلت** | 6 نجحت |

كلا مدقّقَي CI (`i18n:check` و`v5:todos`) مُدرجان في `.github/workflows/ci.yml` (خطوتان بدون شرط)، أي أن خط CI كان سيفشل على النسخة الأصلية.

## 3د. بعد FIXED-5 (R26 وR17 وR33)

- **لم يُنفَّذ:** تشغيل nginx فعليًا (لا ملف تنفيذي هنا؛ تحقق منه المحاكاة وفحص توازن الأقواس فقط) وتشغيل الخادم لاختبار ردود 400 الجديدة؛ المتحكّمات لا تُستورد دون Express.
- ما زالت `enterprise.controller.ts` و`global-completion.controller.ts` غير مغطاة باختبارات تكامل تمرّ عبر HTTP.

## 3ج. تعديلات الجزء الخامس التي **لم تُختبر** تنفيذًا

- كل ما يمر عبر قاعدة البيانات: `deliverNotification` (الاستعلام عن التسليم السابق، إلغاء الأجهزة)، سقف 25 جهازًا و`limit(200)`، تجميع `getFeedbackCountsForOrganization` بـ`count()`/`groupBy`، `onConflictDoNothing` لتفضيلات مساحة العمل، `limit(1000)` للأحداث، وتحققات المعرّفات في الإنتاجية.
- FCM الحقيقي (المهلة وتصنيف الأخطاء مختبران كقواعد نقية فقط)، وGemini الحقيقي، ومزوّدو التهديدات/الروابط.
- **ملفات اختبار المشروع الأصلية لهذه الوحدات** (`ai.service.test.ts`, `ai-policy.test.ts`, `threat-protection.service.test.ts`, `api.test.ts`…) لم تُشغَّل (تحتاج vitest وقاعدة بيانات). راجعتُ توافقها بالقراءة: لا تعتمد على السلوك الذي غيّرتُه (أخطاء 503/504 ما زالت تُحتسب وتُعاد، وروابط الاختبار مفردة).
- أداة الاختبار المحلية ليست vitest: ينقصها بعض المطابقات (أُضيف `toMatchObject`)، فاختبارات هذا الجزء مكتوبة بصيغة vitest القياسية ويلزم تشغيلها بـvitest الحقيقي عندك.

## 3ب. تعديلات الجزء الرابع التي **لم تُختبر** تنفيذًا

- `addMember` / `updateMemberRole` / `updateIncident` / `createOrganization` على قاعدة بيانات (لا Postgres هنا): اختُبرت القواعد النقية فقط، أما استعلامات Drizzle (`setWhere`، المعاملة، فحص العضوية) فلم تُشغَّل. `drizzle-orm 0.45.2` يدعم `setWhere`.
- `global-completion.service.ts` نفسه (يحتاج قاعدة بيانات)، و`securityCsv` الكامل.
- حظر الصور في `EmailDetail` (`remote-images.ts`): **لم يُجرَّب في أي متصفح ولم تُكتب له مواصفة**؛ تحقق منه فحص الصياغة والأنواع الجزئي فقط.

## 4. لم يُنفَّذ — تعذّر بسبب البيئة

| الفحص | السبب | الأمر الذي عليك تشغيله |
|-------|-------|--------------------------|
| تثبيت الاعتماديات بملفات القفل | لا شبكة/لا pnpm | `pnpm install --frozen-lockfile` |
| `tsc` الكامل (`typecheck:libs` + `typecheck`) | لا `node_modules` | `pnpm run typecheck` |
| vitest (`test:integration`) وjest (`test:unit`) وبقية اختبارات الـAPI، بما فيها `worker-shutdown.integration.test.ts` الذي يشغّل `build.mjs` المعدَّل | لا اعتماديات/لا قاعدة بيانات | `pnpm run test:unit && pnpm run test:integration` |
| `prisma validate / generate / migrate deploy` | لا اعتماديات/لا Postgres | `pnpm run db:validate` ثم `pnpm run db:migrate:deploy` على نسخة تجريبية |
| بناء الإنتاج (`build.mjs` كاملًا، `vite build`) | لا `esbuild-plugin-pino` ولا Vite | `pnpm run build` |
| اختبارات ClamAV الحقيقية (EICAR، تعذّر المحرك) | لا `clamd` | تشغيل `scripts/start-production.sh` ثم رفع ملف اختبار EICAR القياسي |
| `flutter analyze` و`flutter test` (بما فيها اختباري `android_manifest_test.dart` و`api_client_refresh_policy_test.dart` الجديدين) وبناء APK | لا Flutter/Dart SDK | `cd mobile/novamail-flutter && flutter pub get && flutter analyze && flutter test` |
| اختبارات Playwright E2E | لا متصفح/اعتماديات | `pnpm run test:e2e` |
| بناء صور Docker (لم يُتحقق من `pnpm install --frozen-lockfile` في مرحلة runner مع workspace جزئي) | لا Docker | `docker compose build` |
| فحص الثغرات (`pnpm audit`) | لا شبكة | `pnpm audit --prod` |
| الحمل واختبارات staging (`load:test`, `staging:smoke`) | تحتاج خادمًا شغّالًا | حسب `docs/staging-deployment-runbook.md` |

## 5. لم يُنفَّذ — يحتاج بيانات اعتماد أو خدمة خارجية

| الفحص | المطلوب |
|-------|---------|
| تدفق Gmail OAuth الكامل (رابط الدخول، callback، تبادل الرمز، التجديد) | `GOOGLE_CLIENT_ID/SECRET`، URI معتمد في Google Cloud، حساب اختبار |
| `users.watch` والـPub/Sub (topic وصلاحية الناشر وOIDC) | وصول إلى مشروع Google Cloud |
| FCM / Web Push / مزوّدو التهديدات والـsandbox / تخزين المرفقات (Replit Object Storage أو S3) | المفاتيح والخدمات الفعلية |
| التحقق من Secrets على Replit أو أي نشر فعلي | وصول إلى لوحة Replit |

لم أتحقق من Google Cloud ولا من الأسرار، ولم أنشر أو أغيّر أي بيانات إنتاج.

## 5ج. الجزء الثالث: الاعتماديات والبناء

- شبكة: `registry.npmjs.org` و`github.com` يعيدان HTTP 000، ولا `~/.npm/_cacache` ولا مخزن pnpm ولا ملفات `.tgz` ولا pnpm؛ لذلك **لم يُحدَّث `pnpm-lock.yaml` ولم تُغيَّر أي اعتمادية** (ملف القفل ما زال متسقًا: 7 importers، 0 مشكلة).
- ضابط المهلة: `fetch()` الخام على خادم متوقف ظل معلقًا بعد 1500 ms؛ `fetchWithTimeout` يرفض خلال المهلة المحددة (اختبار 6/6).
- حزم مهملة في القفل (للعلم فقط، لم تُغيَّر): `@types/bcryptjs` و`@types/express-rate-limit` (نصوص بديلة)، `cron-parser@4.9.0`، `recharts@2.15.4`، و`glob@7/10` وinflight وnode-domexception (اعتماديات غير مباشرة). و`@types/node` 25.9.5 بينما وقت التشغيل Node 24 (تباين أنواع/تشغيل محتمل).

## 5ب. مراجعة الجزء الثاني (قراءة فقط، دون تشغيل)

راجعتُ بالقراءة: `deploy/Caddyfile` (HSTS وترويسات أمان وتوجيه `/api`)، `deploy/redis/redis.conf` (TLS فقط مع mTLS)، `docker-compose.production.yml` (Postgres وRedis على شبكة داخلية فقط، أسرار إلزامية عبر `:?`، وخدمة ترحيل `prisma:migrate:deploy`)، `artifacts/novamail-web/nginx.conf`، وحدة الإدارة، `sanitize-email-html.ts`، ووحدة تسليم الـwebhooks (تثبيت عنوان DNS عند الاتصال، منع إعادة التوجيه، مهلة 30 ثانية، تشفير أسرار الـwebhooks بـAES-256-GCM). لم تُشغَّل (لا Docker/Caddy/Redis/Postgres هنا).

## 6. ملاحظات إضافية من الفحوصات المنفَّذة

- **مقارنة المخطط (Prisma ↔ Drizzle ↔ الترحيلات، الحالة النهائية):** 31 نموذج Prisma، 40 جدول Drizzle، 40 جدولًا بعد الترحيلات الـ29.
  - لا أعمدة Drizzle غائبة عن قاعدة البيانات، ولا أعمدة `NOT NULL` بلا قيمة افتراضية غائبة عن Drizzle (0 و0).
  - 3 جداول Drizzle (`billing_plans`, `billing_subscriptions`, `billing_usage`) بلا ترحيل؛ وحدة الفوترة غير موصولة بأي مسار (الاستخدام الوحيد في اختبار).
  - 9 جداول في الترحيلات غير معرّفة في Prisma؛ ونموذج Prisma `Email` أقدم من الجدول الفعلي (أعمدة `body`, `sender`, `recipient`, …). **لا تشغّل `prisma migrate dev` على قاعدة مشتركة**؛ استعمل `migrate deploy`. ملف `migration_lock.toml` غير موجود في الأرشيف.
- **فحص أسرار مستقل (القيم لم تُطبع):** لا مفاتيح خاصة ولا رموز Google/AWS/GitHub/Slack/Stripe ولا JWT. 12 تطابقًا لعناوين قواعد بيانات بكلمات مرور داخل ملفات CI/README/compose (مضيفات محلية أو حاويات خدمات). **راجع** السطر 159 في `README.md` وتأكد أنه مثال لا كلمة مرور حقيقية.
- `worker-shutdown.integration.test.ts` يشغّل `build.mjs`؛ تعديلي عليه (نسخ `vendor`/`assets`) سيُختبر فعليًا في CI عندك.

## 7. إعادة إنتاج الفحوصات المنفَّذة هنا

الفحوصات 1–5 و10–14 و17 مكتوبة كسكربتات صغيرة خارج المشروع (تحليل بـTypeScript API، مقارنة المخطط، جامع التوطين). لم تُضمَّن في الأرشيف حتى لا تضيف ملفات غير مطلوبة؛ يمكن إعادة كتابتها عند الطلب.
