ALTER TABLE "organization_webhooks"
  ADD COLUMN IF NOT EXISTS "secret_encrypted" TEXT;

CREATE TABLE IF NOT EXISTS "webhook_delivery_outbox" (
  "id" TEXT PRIMARY KEY,
  "webhook_id" TEXT NOT NULL,
  "organization_id" TEXT NOT NULL,
  "event_id" TEXT NOT NULL,
  "event" TEXT NOT NULL,
  "payload" TEXT NOT NULL,
  "job_key" TEXT NOT NULL,
  "queue_name" TEXT NOT NULL,
  "status" "dispatch_status" NOT NULL DEFAULT 'pending',
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "max_attempts" INTEGER NOT NULL DEFAULT 5,
  "available_at" TIMESTAMPTZ NOT NULL,
  "next_attempt_at" TIMESTAMPTZ,
  "lease_expires_at" TIMESTAMPTZ,
  "last_error" TEXT,
  "last_status_code" INTEGER,
  "completed_at" TIMESTAMPTZ,
  "duration_ms" INTEGER,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT "webhook_delivery_outbox_webhook_fk" FOREIGN KEY ("webhook_id") REFERENCES "organization_webhooks"("id") ON DELETE CASCADE,
  CONSTRAINT "webhook_delivery_outbox_organization_fk" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "webhook_delivery_outbox_job_key_unique" ON "webhook_delivery_outbox" ("job_key");
CREATE INDEX IF NOT EXISTS "webhook_delivery_outbox_due_idx" ON "webhook_delivery_outbox" ("status", "available_at", "next_attempt_at", "id");
CREATE INDEX IF NOT EXISTS "webhook_delivery_outbox_lease_idx" ON "webhook_delivery_outbox" ("status", "lease_expires_at");
CREATE INDEX IF NOT EXISTS "webhook_delivery_outbox_webhook_idx" ON "webhook_delivery_outbox" ("webhook_id", "created_at");
